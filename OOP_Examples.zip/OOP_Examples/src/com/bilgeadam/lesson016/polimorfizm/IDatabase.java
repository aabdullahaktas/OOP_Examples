package com.bilgeadam.lesson016.polimorfizm;

public interface IDatabase {

	void save();

}
