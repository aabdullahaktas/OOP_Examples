package com.bilgeadam.lesson016;

public class MarketYonetim {

	private Market market;

	public MarketYonetim() {

	}

	public MarketYonetim(Market market) {
		this.market = market;
	}

	public Market getMarket() {
		return market;
	}

	public void setMarket(Market market) {
		this.market = market;
	}

}
