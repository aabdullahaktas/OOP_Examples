package com.bilgeadam.lesson002;
/*
 * Ekrana 5 defa merhaba yazdıralım
 * 
 */
public class Question9 {
	
	
	public static void main(String[] args) {
		
		System.out.println("Merhaba");
		System.out.println("Merhaba");
		System.out.println("Merhaba");
		System.out.println("Merhaba");
		System.out.println("Merhaba");
		System.out.println("//////For dongusu////");
		
		for(int i=0;i<5;i++) {
			int sayi=5;
			System.out.println("Merhaba");
			System.out.println(sayi);//5
		}
		
		int sayi=10;
		
		int i=5;
		System.out.println(sayi);//10
	}

}
