package com.bilgeadam.lesson019.queue;

public class Musteri2 {

	String isim;
	int yas;

	public Musteri2(String isim, int yas) {
		super();
		this.isim = isim;
		this.yas = yas;
	}

	@Override
	public String toString() {
		return "Musteri [isim=" + isim + ", yas=" + yas + "]";
	}

}
