package com.bilgeadam.lesson033.liskovsusbstition;

public interface ISocialMedia {

	void sharePhoto();

	void shareStory();

	void chat();
}
