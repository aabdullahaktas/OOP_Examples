package com.bilgeadam.lesson033.liskovsusbstition;

public interface IConferencable {

	void videoConferancing();
}
