package com.bilgeadam.lesson033.liskovsusbstition;

import com.bilgeadam.lesson033.utility.User;

public interface ISms {

	void sendSms(User user);

}
