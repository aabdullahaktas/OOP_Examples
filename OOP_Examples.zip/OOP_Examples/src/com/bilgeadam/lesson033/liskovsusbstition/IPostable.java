package com.bilgeadam.lesson033.liskovsusbstition;

public interface IPostable {

	void sharePost();
}
