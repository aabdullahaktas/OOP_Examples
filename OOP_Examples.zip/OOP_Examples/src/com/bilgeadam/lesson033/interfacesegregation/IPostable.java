package com.bilgeadam.lesson033.interfacesegregation;

public interface IPostable {

	void sharePost();
}
