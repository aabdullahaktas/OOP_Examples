package com.bilgeadam.lesson033.interfacesegregation;

import com.bilgeadam.lesson033.utility.User;

public interface ISms {

	void sendSms(User user);

}
