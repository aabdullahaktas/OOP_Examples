package com.bilgeadam.lesson033.interfacesegregation;

public interface ISharableStory {
	void shareStory();
}
