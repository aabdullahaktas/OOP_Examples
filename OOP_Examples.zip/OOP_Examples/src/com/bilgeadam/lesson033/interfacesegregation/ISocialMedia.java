package com.bilgeadam.lesson033.interfacesegregation;

public interface ISocialMedia {

	void sharePhoto();

	void chat();
}
