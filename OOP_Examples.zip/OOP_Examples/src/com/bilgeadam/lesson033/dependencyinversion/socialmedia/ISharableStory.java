package com.bilgeadam.lesson033.dependencyinversion.socialmedia;

public interface ISharableStory {
	void shareStory();
}
