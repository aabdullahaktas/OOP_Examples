package com.bilgeadam.lesson033.dependencyinversion.socialmedia;

public interface ISocialMedia {

	void sharePhoto();

	void chat();
}
