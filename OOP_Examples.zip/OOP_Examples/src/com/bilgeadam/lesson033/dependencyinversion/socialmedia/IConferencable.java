package com.bilgeadam.lesson033.dependencyinversion.socialmedia;

public interface IConferencable {

	void videoConferancing();
}
