package com.bilgeadam.lesson033.dependencyinversion.databaselogger;

public class MongoDb {

	public void log(String ex) {
		System.out.println(ex + " ---> mongoya loglandı");

	}

}
