package com.bilgeadam.lesson033.dependencyinversion.databaselogger;

public class PostgreSql {

	public void log(String ex) {
		System.out.println(ex + " ---> postgreye loglandı");

	}

}
