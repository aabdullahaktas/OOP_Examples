package com.bilgeadam.lesson033.dependencyinversion.databaselogger.çözüm;

public interface ILogger {

	void log(String ex);

}
