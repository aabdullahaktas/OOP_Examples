package com.bilgeadam.kitapkiralama;

public class Kiralama {

}
