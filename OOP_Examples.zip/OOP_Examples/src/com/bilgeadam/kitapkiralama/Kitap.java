package com.bilgeadam.kitapkiralama;

public class Kitap {

}
