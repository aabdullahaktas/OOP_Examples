package com.bilgeadam.lesson017;

public class YolcuUcagi extends Ucak {

}
