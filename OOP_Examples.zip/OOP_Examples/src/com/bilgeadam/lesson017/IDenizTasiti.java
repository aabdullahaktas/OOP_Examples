package com.bilgeadam.lesson017;

public interface IDenizTasiti {

	void yelkenAc();

	void limanaYanas();

}
