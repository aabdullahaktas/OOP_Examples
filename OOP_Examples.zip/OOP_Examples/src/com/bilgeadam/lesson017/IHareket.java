package com.bilgeadam.lesson017;

public interface IHareket {
	void hizlanma();

	void yavaslama();
}
