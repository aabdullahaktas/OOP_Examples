package com.bilgeadam.lesson017;

public interface IHavaTasiti {

	void kalkisYap();

	void inisYap();

}
