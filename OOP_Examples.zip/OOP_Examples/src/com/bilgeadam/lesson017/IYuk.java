package com.bilgeadam.lesson017;

public interface IYuk {

	void yukAl();

	void yukBosalt();

}
