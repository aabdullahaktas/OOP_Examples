package com.bilgeadam.lesson017;

public interface IKaraTasiti {

	void sur();

}
