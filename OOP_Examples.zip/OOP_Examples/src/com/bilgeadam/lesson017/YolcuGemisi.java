package com.bilgeadam.lesson017;

public class YolcuGemisi extends Gemi {

}
