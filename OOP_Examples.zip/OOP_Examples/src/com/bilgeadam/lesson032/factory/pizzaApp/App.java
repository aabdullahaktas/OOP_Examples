package com.bilgeadam.lesson032.factory.pizzaApp;

public class App {

	public static void main(String[] args) {

		PizzaSiparis pizzaSiparis = new PizzaSiparis();
		pizzaSiparis.menu();

	}

}
