package com.bilgeadam.lesson032.factory.pizzaApp;

public enum EHamurTipi {

	INCE, NORMAL, KALIN
}
