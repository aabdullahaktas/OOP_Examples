package com.bilgeadam.lesson032.factory;

public interface ILogger {

	void logToDatabase(String message);

}
