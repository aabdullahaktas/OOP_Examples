package com.bilgeadam.lesson014;

public enum EUrun {
	CIPS, KOLA, SEKER, YAG, UN, EKMEK, ÇAY, YUMURTA, YOGURT, SUT
}
