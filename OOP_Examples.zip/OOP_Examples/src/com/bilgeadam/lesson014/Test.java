package com.bilgeadam.lesson014;

public class Test {

	public static void main(String[] args) {

//		Kullanici kullanici1 = new Kullanici(1, "musty", "123", "Mustafa");
//		System.out.println(kullanici1.getIsim());
//		System.out.println(kullanici1.getUsername());
//		System.out.println(kullanici1.getSepet().getTotalPrice());
//		// kullanici1.getSepet().setUrunler(new EUrun[3]);
//
//		kullanici1.getSepet().getUrunler()[0] = EUrun.CIPS;
//		kullanici1.getSepet().getUrunler()[1] = EUrun.KOLA;
//
//		System.out.println(Arrays.toString(kullanici1.getSepet().getUrunler()));
//		for (EUrun urun : kullanici1.getSepet().getUrunler()) {
//			if (urun != null) {
//				System.out.println(urun.name());
//			}
//		}
//		Database.baslangicVerisiEkle();
//
//		for (Kullanici kullanici : Database.kullanicilar) {
//			if (kullanici != null) {
//				System.out.println(kullanici);
//			}
//
//		}

		Uygulama uygulama = new Uygulama();
		uygulama.uygulamayiBaslat();

	}
}
