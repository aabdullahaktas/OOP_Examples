package com.bilgeadam.lesson029.okulApp;

public enum EDurum {

	GECTI, KALDI

}
