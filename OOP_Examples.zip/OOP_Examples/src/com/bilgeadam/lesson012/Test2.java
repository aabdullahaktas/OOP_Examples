package com.bilgeadam.lesson012;

public class Test2 {

	public static void main(String[] args) {

		// System.out.println(TasKagitMakas.secimYap());

		TasKagitMakas.oyun();

	}

}
