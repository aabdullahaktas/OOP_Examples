package com.bilgeadam.lesson012;

public enum ESecenek {

	TAS, KAGIT, MAKAS

}
