package com.bilgeadam.lesson022.streamapi;

public class Test {

	public void topla() {
		System.out.println(10);
	}

}
