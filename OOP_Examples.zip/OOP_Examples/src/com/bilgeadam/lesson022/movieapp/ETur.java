package com.bilgeadam.lesson022.movieapp;

public enum ETur {
	KORKU, GERILIM, DRAMA, GİZEM, ANİME, KOMEDI, BILIM_KURGU, ANIMASYON, KARA_MIZAH
}
