package com.bilgeadam.lesson022.movieapp;

import java.util.ArrayList;
import java.util.List;

public class Database {

	public static List<Film> filmList = new ArrayList<>();

	public static List<Cast> casts = new ArrayList<>();
}
