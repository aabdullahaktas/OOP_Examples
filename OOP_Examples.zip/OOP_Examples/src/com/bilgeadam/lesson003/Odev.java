package com.bilgeadam.lesson003;

/*
 * 
 * Soru1-) Dışarıdan taban değeri birde üs değeri alacağız
 * ( 2 üzeri 5 gibi ) bu işlemin sonucu bulan algoritma( dongu kullanarak)
 * 
 * Soru2-)  a dan z ye kadar alafabeyi yazdıralım ;( dongu kullanarak)
 * 
 * Soru3-)Klavyeden 0 girilinceye kadar sayı okumaya devam edeceğiz 
 * 0 girilidğinde sayıların toplamını ve ortalamasını ekrana yazdıralım  
 * 
 * Soru4-)/*
 * 1 den 100 ekadar olan çift sayıların toplamının
 * tek sayıların toplamına oranı 
 * 
 * Wrapper class nedir 
 * heap bellek stack bellek arasındaki fark 
 * referans tur nedir 
 * 
 * 
 */

public class Odev {

}
