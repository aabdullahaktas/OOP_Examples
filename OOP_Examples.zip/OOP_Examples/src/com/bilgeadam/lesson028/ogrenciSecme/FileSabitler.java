package com.bilgeadam.lesson028.ogrenciSecme;

public class FileSabitler {

	public static final String OGRENCI_LIST_FILE = "E:/java10-workspace/dosya/ogrenci.txt";

	public static final String OGRENCI_LIST_FILE_COPY = "E:/java10-workspace/dosya/ogrenci_list_copy.txt";

	public static final String ALINAN_OGRENCI = "E:/java10-workspace/dosya/alinan_ogrenci.txt";

}
