package com.bilgeadam.lesson028;

public class FileSabitler2 {

	public static final String PATH = "E:/java10-workspace/dosya/fileislemler.txt";

}
