package com.bilgeadam.lesson028;

public class FileManager {

	public static void main(String[] args) {

		FileIslemler fileIslemler = new FileIslemler();
		fileIslemler.uygulama();

	}
}
