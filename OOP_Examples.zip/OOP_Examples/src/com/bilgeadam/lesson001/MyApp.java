package com.bilgeadam.lesson001;
/*
 * Pascal Case isimlendirme
 * sınıflarda pascal case isimlendirmesini kullanıcagız
 * 
 * 
 */
public class MyApp {

}
