package com.bilgeadam.lesson015;

public class Laptop extends Bilgisayar {
	private double sarjYuzdesi;
	private String ekran;
	private String batarya;

}
