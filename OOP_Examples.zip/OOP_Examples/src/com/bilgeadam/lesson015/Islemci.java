package com.bilgeadam.lesson015;

public class Islemci extends DahiliDonanim {

	private int cekirdekSayisi;
	private int hiz;
}
