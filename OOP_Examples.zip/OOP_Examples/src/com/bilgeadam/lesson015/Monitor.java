package com.bilgeadam.lesson015;

public class Monitor extends HariciDonanim {
	private int boyut;
	private int kareHizi;
}
