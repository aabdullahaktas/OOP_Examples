package com.bilgeadam.lesson015;

public class Masaustu extends Bilgisayar {
	private String monitor;
	private int kasaBoyutu;
}
