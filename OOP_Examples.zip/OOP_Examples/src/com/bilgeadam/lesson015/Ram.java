package com.bilgeadam.lesson015;

public class Ram extends DahiliDonanim {
	private int boyut;
	private int hiz;
}
