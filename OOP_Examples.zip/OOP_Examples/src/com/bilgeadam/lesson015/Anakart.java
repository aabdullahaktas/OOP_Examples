package com.bilgeadam.lesson015;

public class Anakart extends DahiliDonanim {

	private DahiliDonanim[] dahiliDonanimlar;

	public DahiliDonanim[] getDahiliDonanimlar() {
		return dahiliDonanimlar;
	}

	public void setDahiliDonanimlar(DahiliDonanim[] dahiliDonanimlar) {
		this.dahiliDonanimlar = dahiliDonanimlar;
	}

}
