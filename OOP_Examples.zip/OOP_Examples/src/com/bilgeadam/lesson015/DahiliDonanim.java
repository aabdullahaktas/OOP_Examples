package com.bilgeadam.lesson015;

public class DahiliDonanim extends Donanim {

}
