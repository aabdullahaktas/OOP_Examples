package com.bilgeadam.lesson015;

public class Klavye extends HariciDonanim {
	private String tur;
	private String stil;
}
