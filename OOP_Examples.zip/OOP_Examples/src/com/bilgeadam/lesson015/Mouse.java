package com.bilgeadam.lesson015;

public class Mouse extends HariciDonanim {

	private String tur;
}
