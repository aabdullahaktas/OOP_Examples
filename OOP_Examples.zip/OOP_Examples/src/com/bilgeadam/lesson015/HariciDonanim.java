package com.bilgeadam.lesson015;

public class HariciDonanim extends Donanim {

}
