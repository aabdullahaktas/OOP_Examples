package com.bilgeadam.ucakApp;

public enum EFirma {

	THY, ADJ, PEGASUS
}
