package com.bilgeadam.lesson018.sehir;

public interface ISehir {

	String plakaKoduUret(int index);

	long rastgeleNufusUret();
}
