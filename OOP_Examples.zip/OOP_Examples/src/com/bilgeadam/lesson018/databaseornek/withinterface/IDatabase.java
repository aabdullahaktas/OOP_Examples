package com.bilgeadam.lesson018.databaseornek.withinterface;

public interface IDatabase {

	void veriEkle();

	void veriSil();

	void veriGuncelle();

	void verileriGetir();

	void login();

}
