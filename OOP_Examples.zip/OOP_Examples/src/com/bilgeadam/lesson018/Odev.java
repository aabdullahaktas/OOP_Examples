package com.bilgeadam.lesson018;

/*
 * 2 tane sınıfımız olacak  databse sınıflarımız Mysql Oracle 
 * 
 * database e veri eklme veri silme veri guncelleme verileri getir metotlarımız olacak 
 * birde   login metodumuz olsun 
 * 1 tanede Manager sınıfmız olsun 
 * bu manger sınıfında  bir menu yapalım 
 * 	System.out.println("1-Veri ekle");
		System.out.println("2-Veri sil");
		System.out.println("3-Veri guncelle");
		System.out.println("4-Verileri getir");
		System.out.println("0-Çıkış");
 * manager sınfıında çalıştır metoduyla beraber console menumuz gelsın ve biz cıkıs yapana kadar 
 * burdaki metotları calıstıralım 
 * 1 veri ekle metodu çalıştıgında beklediğimiz çıktı
 * ----> Mysql veritabanına veri eklendi veya Oracle veri tabanına veri eklendi 
 * 
 * 
 * 
 * 
 */
public class Odev {

}
