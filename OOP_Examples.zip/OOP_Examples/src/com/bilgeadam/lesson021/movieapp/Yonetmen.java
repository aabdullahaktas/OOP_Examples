package com.bilgeadam.lesson021.movieapp;

public class Yonetmen extends Cast {

	public Yonetmen(String isim, String soyIsim) {
		super(isim, soyIsim);
		// TODO Auto-generated constructor stub
	}

}
