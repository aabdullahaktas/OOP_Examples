package com.bilgeadam.lesson021.movieapp;

public enum ETur {
	KORKU, GERILIM, DRAMA, GİZEM, ANİME, KOMEDI, BILIM_KURGU, ANIMASYON, KARA_MIZAH
}
