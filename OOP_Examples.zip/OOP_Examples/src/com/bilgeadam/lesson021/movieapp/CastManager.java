package com.bilgeadam.lesson021.movieapp;

public class CastManager implements ICrud<Cast> {

	@Override
	public Cast kayitEt(Cast t) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void guncelle(Cast t) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sil(Long id) {
		// TODO Auto-generated method stub

	}

}
