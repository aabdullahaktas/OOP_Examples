package com.bilgeadam.lesson021.movieapp;

public class Oyuncu extends Cast {

	public Oyuncu(String isim, String soyIsim) {
		super(isim, soyIsim);
		// TODO Auto-generated constructor stub
	}

}
