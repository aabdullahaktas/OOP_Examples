package com.bilgeadam.lesson021.movieapp;

public class FilmManager implements ICrud<Film> {

	@Override
	public Film kayitEt(Film t) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void guncelle(Film t) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sil(Long id) {
		// TODO Auto-generated method stub

	}

}
